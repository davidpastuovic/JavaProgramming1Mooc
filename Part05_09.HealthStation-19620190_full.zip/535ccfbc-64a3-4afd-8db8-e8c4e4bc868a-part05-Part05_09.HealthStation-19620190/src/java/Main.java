
public class Main {

    public static void main(String[] args) {
        // write experimental code here to check how your program functions
    }
}
