
import java.util.Scanner;

public class NumberAndSumOfNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int zbroj = 0;
        int brojUnosa = 0;
        
        while(true){
            System.out.println("Give a number:");
            int number = Integer.valueOf(scanner.nextLine());
            
            if(number == 0){
                break;
            }
            zbroj = zbroj + number;
            brojUnosa = brojUnosa + 1;
        }
        System.out.println("Number of numbers: " + brojUnosa);
        System.out.println("Sum of the numbers: " + zbroj);
    }
}
