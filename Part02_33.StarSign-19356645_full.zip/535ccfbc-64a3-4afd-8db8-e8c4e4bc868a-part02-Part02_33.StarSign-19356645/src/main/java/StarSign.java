
public class StarSign {

    public static void main(String[] args) {

        printStars(5);
        System.out.println("\n---");  // printing --- between the shapes
        printSquare(4);
        System.out.println("\n---");
        printRectangle(15, 5);
        System.out.println("\n---");
        printTriangle(5);
        System.out.println("\n---");  
        
    }

    public static void printStars(int number) {
        // first part of the exercise
        int i = 0;
        while (i < number) {
            System.out.print("*");
            i++;
        }
        System.out.println("");

    }

    public static void printSquare(int size) {
        // second part of the exercise
        int i = 0;
        while (i < size) {
            printStars(size);
            i++;
        }
    }

    public static void printRectangle(int width, int height) {
        // third part of the exercise
        int i = 0;
        while (i < height) {
            printStars(width);
            i++;
        }

    }

    public static void printTriangle(int size) {
        // fourth part of the exercise
        int i = 0;
        while (i < size) {
            printStars(i + 1);
            i++;

        }
    }
}
