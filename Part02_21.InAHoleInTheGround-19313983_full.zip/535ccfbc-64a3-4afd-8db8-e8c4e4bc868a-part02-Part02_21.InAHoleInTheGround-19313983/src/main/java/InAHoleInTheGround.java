public class InAHoleInTheGround {

    public static void main(String[] args) {
        printText();
    }
    
    public static void printText() {
        // Write some code in here
        System.out.println("In a hole in the ground there lived a method");
    }
}
