
public class OnceUponATime {

    public static void main(String[] args) {
        // Write your program here
        System.out.println("Once upon a time");
        System.out.println("there was");
        System.out.println("a program");
    }
}
