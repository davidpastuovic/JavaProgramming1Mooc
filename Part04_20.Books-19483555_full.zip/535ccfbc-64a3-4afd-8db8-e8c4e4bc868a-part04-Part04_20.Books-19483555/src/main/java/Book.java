
public class Book {

    private String title;
    private int numberOfPages;
    private int publicationYear;

    public Book(String initTitle, int initPages, int initPubYear) {

        this.title = initTitle;
        this.numberOfPages = initPages;
        this.publicationYear = initPubYear;

    }

    public String getTitle() {
        return this.title;
    }

    @Override
    public String toString() {
        return this.title + ", " + this.numberOfPages + " pages, " + this.publicationYear;
    }
}
