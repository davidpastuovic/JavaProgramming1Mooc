
import java.util.ArrayList;

public class Suitcase {

    private ArrayList<Item> items;
    private int maxWeight;

    public Suitcase(int initMaxWeight) {
        this.items = new ArrayList<>();
        this.maxWeight = initMaxWeight;

    }

    public void addItem(Item item) {
        int currentWeight = 0;
        for (Item stuff : items) {
            currentWeight = currentWeight + stuff.getWeight();

        }
        if (item.getWeight() + currentWeight <= this.maxWeight) {
            this.items.add(item);

        }
    }
    public void printItems () {
        
        for (Item stuff : items) {
            System.out.println(stuff);
        }
    }
    public int totalWeight () {
        int totalWeight = 0;
        for (Item total : items) {
            totalWeight = totalWeight + total.getWeight();
        }
        return totalWeight;
    }
    public Item heaviestItem () {
        if (this.items.isEmpty()) {
            return null;
        }
        Item returnObject = this.items.get(0);
        for (Item stuff : items) {
            if (returnObject.getWeight() < stuff.getWeight() ) {
                returnObject = stuff;
            }
        }
        return returnObject;
    }

    @Override
    public String toString() {
        if (this.items.isEmpty()) {
            return "no items (0 kg)";
        }
        
        
        int currentWeight = 0;
        String itemPluralNaming = "item";
        if (this.items.size() > 1){
            itemPluralNaming = "items";
        }
        for (Item stuff : items) {
            currentWeight = currentWeight + stuff.getWeight();
        }
        if (currentWeight <= this.maxWeight) {
            return this.items.size() + itemPluralNaming + " (" + currentWeight + " kg)";
        }
        return this.items.size() + itemPluralNaming + " (" + currentWeight + " kg)";
    }
}
