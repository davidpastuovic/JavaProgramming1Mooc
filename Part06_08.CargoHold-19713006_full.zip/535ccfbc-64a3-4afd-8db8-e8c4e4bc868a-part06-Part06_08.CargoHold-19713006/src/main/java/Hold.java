
import java.util.ArrayList;

public class Hold {

    private ArrayList<Suitcase> suitcases;
    private int maximumWeight;

    public Hold(int initMaxWeight) {
        this.suitcases = new ArrayList<>();
        this.maximumWeight = initMaxWeight;
    }

    public void addSuitcase(Suitcase suitcase) {
        int currentWeight = 0;
        for (Suitcase stuff : suitcases) {
            currentWeight = currentWeight + stuff.totalWeight();

        }
        if (suitcase.totalWeight() +  currentWeight <= this.maximumWeight) {
            this.suitcases.add(suitcase);

        }
    }
    public void printItems() {
        for (Suitcase suitcase : suitcases) {
            suitcase.printItems();
        }
    }
    @Override
    public String toString() {
        int currentWeight = 0;
        for (Suitcase stuff : suitcases) {
            currentWeight = currentWeight + stuff.totalWeight();

        }
        return this.suitcases.size() + " suitcases (" + currentWeight + " kg)";
    }
}
