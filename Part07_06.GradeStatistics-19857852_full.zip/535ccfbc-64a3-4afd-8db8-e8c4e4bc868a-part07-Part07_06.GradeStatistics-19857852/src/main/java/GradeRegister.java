
import java.util.ArrayList;

public class GradeRegister {

    private ArrayList<Integer> points;
    private ArrayList<Integer> grades;

    public GradeRegister() {
        this.points = new ArrayList<>();
        this.grades = new ArrayList<>();
    }

    public void add(int points) {
        if (points >= 0 && points <= 100) {
            this.points.add(points);
            this.grades.add(GradeDistribution(points));
        }
    }

    public double pointsAverage() {
        int sum = 0;
        double average = 0;
        for (int i = 0; i < this.points.size(); i++) {
            sum += this.points.get(i);
            average = 1.0 * sum / this.points.size();
        }
        return average;

    }

    public double pointsAveragePassing() {
        int sum = 0;
        int count = 0;
        for (int i = 0; i < this.points.size(); i++) {
            if (this.points.get(i) >= 50) {
                count++;
                sum += this.points.get(i);

            }

        }

        return 1.0 * sum / count;
    }

    public double passPercentage() {
        int count = 0;
        for (int i = 0; i < this.points.size(); i++) {
            if (this.points.get(i) >= 50) {
                count++;
            }
        }
        return 100.0 * count / this.points.size();
    }

    public void printStars(int stars) {
        while (stars > 0) {
            System.out.print("*");
            stars--;
        }
    }

    public int GradeDistribution(int points) {
        int grade;
        if (points < 50) {
            grade = 0;
        } else if (points < 60) {
            grade = 1;
        } else if (points < 70) {
            grade = 2;
        } else if (points < 80) {
            grade = 3;
        } else if (points < 90) {
            grade = 4;
        } else {
            grade = 5;
        }

        return grade;
    }

    public int numberOfGrades(int grade) {
        int count = 0;
        for (int received : this.grades) {
            if (received == grade) {
                count++;
            }
        }

        return count;
    }

    public void printGradeDistribution() {
        int grade = 5;

        while (grade >= 0) {
            int stars = numberOfGrades(grade);
            System.out.print(grade + ": ");
            printStars(stars);
            System.out.println("");

            grade = grade - 1;
        }

    }
}