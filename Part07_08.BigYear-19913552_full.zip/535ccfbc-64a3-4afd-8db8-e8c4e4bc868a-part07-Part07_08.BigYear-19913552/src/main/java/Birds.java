
public class Birds {

    private String name;
    private String LatinName;
    private int observation;

    public Birds(String name, String LatinName) {
        this.name = name;
        this.LatinName = LatinName;
        this.observation = 0;

    }

    public void addName(String name) {
        this.name = name;

    }

    public String getName() {
        return this.name;
    }

    public void addLatinName(String name) {
        this.LatinName = name;
    }

    public String getLatinName() {
        return this.LatinName;
    }

    public void addObservation() {
        this.observation++;
    }
    public int getObservations () {
        return this.observation;
    }
    
    @Override
    public String toString () {
        return this.name + " (" + this.LatinName + "): " + this.observation + " observations";
    }

}
