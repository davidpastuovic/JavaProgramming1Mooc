
import java.util.ArrayList;
import java.util.Scanner;

public class mainProgram {

    public static void main(String[] args) {
        // NB! Do not create other scanner objects than the one below
        // if and when you create other classes, pass the scanner to them
        // as a parameter

        Scanner scan = new Scanner(System.in);
        ArrayList<Birds> bird = new ArrayList<>();

        while (true) {
            System.out.println("?");
            String input = scan.nextLine();
            if (input.equals("Quit")) {
                break;
            } else if (input.equals("Add")) {
                System.out.println("Name?");
                String birdName = scan.nextLine();
                System.out.println("Name in Latin?");
                String latinName = scan.nextLine();

                bird.add(new Birds(birdName, latinName));

            } else if (input.equals("Observation")) {
                System.out.println("Bird?");
                String birdName = scan.nextLine();
                /*if (!bird.contains(birdName)) {
                    System.out.println("Not a bird!");
                }else {*/
                for (Birds wanted : bird) {
                    if (wanted.getName().equals(birdName)) {
                        wanted.addObservation();
                    } else {
                        System.out.println("Not a bird!");
                    }
                }

            } else if (input.equals("All")) {
                for (Birds wanted : bird) {
                    System.out.println(wanted);
                }

            } else if (input.equals("One")) {
                System.out.println("Bird?");
                String birdName = scan.nextLine();
                for (Birds wanted : bird) {
                    if (wanted.getName().equals(birdName)) {
                        System.out.println(wanted);
                    }
                }

            } else {
                System.out.println("Invalid input.");
            }
        }

    }

}
