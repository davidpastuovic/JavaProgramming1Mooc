
import java.util.Scanner;

public class SimpleCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        System.out.println("Give the first number:");
        int prvi = Integer.valueOf(scanner.nextLine());
        System.out.println("Give the second number:");
        int drugi = Integer.valueOf(scanner.nextLine());
        int zbroj = prvi + drugi;
        int razlika = prvi - drugi;
        int umnozak = prvi * drugi;
        double kolicnik = 1.0*prvi/drugi;
        System.out.println(prvi + " + " + drugi + " = " + zbroj);
        System.out.println(prvi + " - " + drugi + " = " + razlika);
        System.out.println(prvi + " * " + drugi + " = " + umnozak);
        System.out.println(prvi + " / " + drugi + " = " + kolicnik);
       
    }
}
