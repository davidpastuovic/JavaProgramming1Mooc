
import java.util.Scanner;

public class DifferentTypesOfInput {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        System.out.println("Give a string:");
        String rijec = scanner.nextLine();
        
        System.out.println("Give an integer:");
        int cijeliBroj = Integer.valueOf(scanner.nextLine());
        
        System.out.println("Give a double:");
        double decimalni = Double.valueOf(scanner.nextLine());
        
        System.out.println("Give a boolean:");
        boolean IstinaLaz = Boolean.valueOf(scanner.nextLine());
        
        System.out.println("You gave the string " + rijec);
        System.out.println("You gave the integer " + cijeliBroj );
        System.out.println("You gave the double " + decimalni);
        System.out.println("You gave the boolean " + IstinaLaz );
    }
}
