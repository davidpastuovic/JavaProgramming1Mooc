
public class Program {

    public static void main(String[] args) {
       


      Book b = new Book("J. K. Rowling", "Harry Potter and the Sorcerer's Stone", 223);
      System.out.println(b);

    }
}
