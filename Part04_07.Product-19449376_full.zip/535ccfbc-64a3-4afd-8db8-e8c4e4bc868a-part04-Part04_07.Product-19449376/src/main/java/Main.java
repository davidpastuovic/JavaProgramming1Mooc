
public class Main {

    public static void main(String[] args) {
  
         Product product = new Product("Banana", 1.1, 13);
         product.printProduct();
    }
}
