
public class Apartment {

    private int rooms;
    private int squares;
    private int pricePerSquare;

    public Apartment(int rooms, int squares, int pricePerSquare) {
        this.rooms = rooms;
        this.squares = squares;
        this.pricePerSquare = pricePerSquare;
    }

    public boolean largerThan(Apartment compared) {
        if (this.squares > compared.squares) {
            return true;
        }
        return false;
    }

    public int priceDifference(Apartment compared) {
        int totalPrice1 = this.squares * this.pricePerSquare;
        int totalPrice2 = compared.squares * compared.pricePerSquare;
        if (totalPrice1 > totalPrice2) {
            return totalPrice1 - totalPrice2;
        } else if (totalPrice1 < totalPrice2) {
            return totalPrice2 - totalPrice1;
        } else {
            return 0;
        }
    }

    public boolean moreExpensiveThan(Apartment compared) {
        int totalPrice1 = this.squares * this.pricePerSquare;
        int totalPrice2 = compared.squares * compared.pricePerSquare;
        if (totalPrice1 > totalPrice2) {
            return true;
        }
        return false;
    }

}


