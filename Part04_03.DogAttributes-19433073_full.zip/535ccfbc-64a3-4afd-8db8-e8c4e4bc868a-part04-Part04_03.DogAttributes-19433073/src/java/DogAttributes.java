
import java.util.Scanner;

public class DogAttributes {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Follow the instructions carefully
        // and run the tests.
    }
}
