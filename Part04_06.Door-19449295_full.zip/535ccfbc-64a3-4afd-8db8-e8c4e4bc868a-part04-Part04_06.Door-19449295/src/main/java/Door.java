
public class Door {
    
    
    public Door () {
        
    }
    public void knock() {
        
        System.out.println("Who's there?");
    }
    
}
