
public class Main {

    public static void main(String[] args) {
        // This is an empty main method
        // You can use it to test your Door class. Try the following:

        Door alexander = new Door();

        alexander.knock();
        alexander.knock();
    }
}
