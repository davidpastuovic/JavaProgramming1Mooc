
public class Money {

    private final int euros;
    private final int cents;

    public Money(int euros, int cents) {

        if (cents > 99) {
            euros = euros + cents / 100;
            cents = cents % 100;
        }

        this.euros = euros;
        this.cents = cents;
    }

    public int euros() {
        return this.euros;
    }

    public int cents() {
        return this.cents;
    }

    public Money plus(Money addition) {
        int incCents = this.cents + addition.cents();
        int incEuros = this.euros + addition.euros();

        Money newMoney = new Money(incEuros, incCents);

        return newMoney;
    }
    public boolean lessThan(Money compared) {
        double thisTotal = this.euros + this.cents / 100.0;
        double comparedTotal = compared.euros() + compared.cents() / 100.0;
        return thisTotal < comparedTotal;
    }
    public Money minus(Money decreaser) {
        int decrCents = this.cents - decreaser.cents();
        int decrEuros = this.euros - decreaser.euros();
         if (decrCents < 0) {
            decrCents += 100;
            decrEuros -= 1;
        }
          if (decrEuros < 0) {
            return new Money(0, 0);
        }
        Money newMoney = new Money (decrEuros, decrCents);
     
        return newMoney;
    }

    public String toString() {
        String zero = "";
        if (this.cents < 10) {
            zero = "0";
        }

        return this.euros + "." + zero + this.cents + "e";
    }

}
