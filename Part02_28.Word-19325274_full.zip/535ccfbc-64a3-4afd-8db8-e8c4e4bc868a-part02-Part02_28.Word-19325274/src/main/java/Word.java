
import java.util.Scanner;

public class Word {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String rijec = word();

    }
    public static String word(){
        return "dinamo";
    }

}
