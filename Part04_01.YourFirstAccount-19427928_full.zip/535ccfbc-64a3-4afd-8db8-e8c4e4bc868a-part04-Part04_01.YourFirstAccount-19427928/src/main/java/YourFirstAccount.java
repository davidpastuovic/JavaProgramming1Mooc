
public class YourFirstAccount {

    public static void main(String[] args) {
        // Do not touch the code in Account.java
        // Write your program here
        Account johnsAccount = new Account("John's account", 100.00);

        System.out.println("Initial state");
        System.out.println(johnsAccount);

        johnsAccount.deposit(20);
        System.out.println("The balance of John's account is now: " + johnsAccount);

        System.out.println("End state");
        System.out.println(johnsAccount);

    }
}
